<?php
/**
 * Description of util
 *
 * @author GFORTI
 */
class Util {

    /**
    * A method to check if a Post request has been made.
    *
    * @return boolean
    */
   public function isPostRequest() {
       return ( filter_input(INPUT_SERVER, 'REQUEST_METHOD') === 'POST' );
   }

   /**
    * A method to check if a Get request has been made.
    *
    * @return boolean
    */
   public function isGetRequest() {
       return ( filter_input(INPUT_SERVER, 'REQUEST_METHOD') === 'GET' );
   }


   public function getDBConfig() {
       return array(
         //'DB_DNS' => 'sqlsrv:Driver={SQL Server Native Client 11.0};Server=sql.neit.edu;Database=SE414_GroupProject',
         'DB_DSN' => 'sqlsrv:server=sql.neit.edu;Database=SE414_GroupProject',
         'DB_USER' => 'SE414_GroupProject',
         'DB_PASSWORD' => '1234567890'
        );
   }

}
