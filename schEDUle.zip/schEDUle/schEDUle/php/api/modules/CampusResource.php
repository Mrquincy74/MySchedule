<?php
/**
 * Class that contains the resources for making any changes to the database
 *
 * @author Mike
 */
require_once './autoload.php';
//TODO: Add more error checking capabilites to the dataCheck function
//ex. Proper syntax, etc.
class CampusResoruce implements IRestModel{


    private $db;
    function __construct() {
        //sets connection to the databse
        $util = new Util();
        $dbo = new DB_Connect($util->getDBConfig());
        $this->setDb($dbo->getDB());
    }
    private function getDb() {
        return $this->db;
    }
    private function setDb($db) {
        $this->db = $db;
    }

    function post($data)
    {
        //Setups up the insert for SQL for post function as well as binding JSON data provided by the data array to the statement
        $stmt = $this->db->prepare("INSERT INTO Campus SET address_1 = :address_1, city = :city, state = :state, zip = :zip, campus_name = :campus_name");
        $binds = array(
            ":address_1" => $data['address_1'],
            ":city" => $data['city'],
            ":state" => $data['state'],
            ":zip" => $data['zip'],
            ":campus_name" => $data['campus_name']
        );

        //Check used to see if all the necessary forms have been filled.
        if($this->dataCheck($data) === true){
            if ($stmt->execute($binds) && $stmt->rowCount() > 0) {
                return 'Campus Added';
                // Displays message on succesfull addition...
            } else {
                throw new Exception('Campus could not be added');
                //.. and throws an exception for faliure.
            }
        }
    }

    public function get($id) {
       //Creates statement used to get specific entry from the datbase based on an id given via endpoint
        $stmt = $this->db->prepare("SELECT * FROM Campus where campus_id = :id");
        $binds = array(":id" => $id);


        if ($stmt->execute($binds) && $stmt->rowCount() > 0) {
            $results = $stmt->fetch(PDO::FETCH_ASSOC);
            //if successfull it will fetch the info generated..
        } else {
            throw new InvalidArgumentException('Campus ID ' . $id . ' was not found');
            //or throws and exception
        }

        return $results;

    }

    public function getAll() {
        //Very similar statment to get(), except this function requires no parameters and returns all entries in the db.
        $stmt = $this->db->prepare("SELECT * FROM Campus");

        $results = array();
        if ($stmt->execute() && $stmt->rowCount() > 0) {
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        return $results;
    }

    public function put($id, $data)
    {
        //Put function uses a stament written to update a pre-existing db entry.
        $stmt = $this->db->prepare("Update Building SET address_1 = :address_1, city = :city, state = :state, zip = :zip, campus_name = :campus_name WHERE campus_id = :campus_id");
        $binds = array(
          ":address_1" => $data['address_1'],
          ":city" => $data['city'],
          ":state" => $data['state'],
          ":zip" => $data['zip'],
          ":campus_name" => $data['campus_name'],
          ":campus_id" => $id
        );
        //once more checking that all neccesary form objects are filled.
        if($this->dataCheck($data) === true){
            if ($stmt->execute($binds) && $stmt->rowCount() > 0) {
                return 'Campus Updated';
            } else {
                throw new Exception('Campus could not be updated');
            }
        }

    }

    public function delete($id) {
        //Delete uses a statment written to delete from the db where the id matches the one located in the endpoint.
        $stmt = $this->db->prepare("DELETE FROM Campus WHERE campus_id = :id");
        $binds = array(":id" => $id);
        if ($stmt->execute($binds) && $stmt->rowCount() > 0) {
            return 'Campus Deleted';
        } else {
            throw new InvalidArgumentException('Campus ID ' . $id . ' was not found');
        }
    }

    public function dataCheck($data) {
        //The dataCheck function uses the JSON data to make sure that all form objects were properly filled out.
        $errors = array();

        if ($data['address_1'] === '' ){
            $errors[] = 'No Address ';
        }
        if ($data['city'] === '' ){
            $errors[] = 'No City ';
        }
        if ($data['state'] === '' ){
            $errors[] = 'No State ';
        }
        if ($data['zip'] === '' ){
            $errors[] = 'No Zip Code ';
        }
        if ($data['campus_name'] === '' ){
            $errors[] = 'No Campus Name ';
        }
        if (count($errors) > 0)
        {
            throw new Exception('Form not fully filled');
        }
        else{
            return true;
        }

    }
}
