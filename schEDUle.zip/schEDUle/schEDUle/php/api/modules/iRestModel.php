<?php
/**
 *
 * @author Mike
 */
interface iRestModel {
    //put your code here
    function getAll();

    function get($id);




}
