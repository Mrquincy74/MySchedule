<?php
  class Login {
    protected $db = null;

    private function getDB(){
      return $this->db;
    }

    private function setDb($db) {
        $this->db = $db;
    }

    public function __construct($db){
      $this->db = $db;
    }

    public function getLogin($mail,$password){
      $pword = $password;
      $password = hash(sha1, $pword, true);

      $stmt = $this->db->prepare('SELECT * FROM [dbo].[User] where [user_name] = :user_name AND [password] = :password');
      //$binds = array(":user_name" => $mail,
        //              ":password" => $password);
      $stmt->bindParam(':user_name', $mail, PDO::PARAM_STR);
      $stmt->bindParam(':password', $password);

      if ($stmt->execute()) {
          $results = $stmt->fetch();
          echo $results;
          //if successfull it will fetch the info generated..
      } else {
          throw new InvalidArgumentException('Login was not found');
          //or throws and exception
          $results = "Login not found.";
      }

      return $results;
    }

    /*public function checkUserLogin($connection,$email, $pass) {
        $pass = sha1($pass);
        $dbs = $connection->prepare('SELECT * FROM user_profiles WHERE email = :email and password = :password');
        // you must bind the data before you execute
        $dbs->bindParam(':email', $email, PDO::PARAM_STR);
        $dbs->bindParam(':password', $pass, PDO::PARAM_STR);
        // When you execute remember that a rowcount means a change was made
        if ($dbs->execute() && $dbs->rowCount() > 0) {
            return true;
        } else {
            return false;
        }
    }*/
  }

?>
