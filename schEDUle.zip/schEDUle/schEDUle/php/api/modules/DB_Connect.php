<?php
  // Disconnect the database from the database handle.
class DB_Connect {

    //private $database_name = "SE414_GroupProject;";
    //private $hostname = "sql.neit.edu;";
    protected $db = null;
    private $dbConfig = array();

    private function getDbConfig() {
        return $this->dbConfig;
    }

    private function setDbConfig($dbConfig) {
        $this->dbConfig = $dbConfig;
    }

    public function __construct($dbConfig) {
        $this->setDbConfig($dbConfig);
    }

    public function getDBConnection(){
      $config = $this->getDbConfig();
      //if ( null != $this->db ) {
          //  return $this->db;
      //  }
        try {
            $config = $this->getDbConfig();
            //$this->db = new PDO("sqlsrv:Server={SQL Server Native Client 11.0};Server=sql.neit.edu\MSSQLSERVER;Database=SE414_GroupProject", "SE414_GroupProject", "1234567890");
            $this ->$db = new PDO("sqlsrv:server=$serverName; Database=SE414_GroupProject", "SE414_GroupProject", "1234567890");
            //$this->$db = new PDO("sqlsrv:server=sql.neit.edu; Database=SE414_GroupProject", "SE414_GroupProject", "1234567890");
            $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        } catch (Exception $ex) {

           $this->closeDB();
           //throw new DBException($ex->getMessage());
           echo $ex;
        }
        return $this->db;
    }

    public function closeDB() {
        $this->db = null;
    }


    //use any of these or check exact MSSQL ODBC drivername in "ODBC Data Source Administrator"

  /*public function getDBConnection(){
    $mssqldriver = 'SQL Server Native Client 11.0';

    $hostname='sql.neit.edu,4500;';
    $dbname='SE414_GroupProject;';
    $username='SE414_GroupProject';
    $password='1234567890';
    $dsn = "sqlsrv:Driver={SQL Server Native Client 11.0};Server=$this->hostname;Database=$this->database_name";
    try {
      $dbDB = new PDO($dsn, "SE414_GroupProject", "1234567890");
    } catch (odbc_error $e) {
      echo 'Connection failed: ' . $e->getMessage();
    }
    return $dbDB;
  }*/


}
?>
