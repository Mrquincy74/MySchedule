<div class="header">
  <h1>Current Courses
    <span class="fa fa-plus-square pull-right" onclick="loadPage('add_edit_subject')"> Add Subject</span>
    <span class="fa fa-plus-square pull-right" onclick="loadPage('add_edit_course')"> Add Course</span>
</h1>
</div>

<div class="accordian-container collapsed">
  <div class="accordian-header" onclick="toggleAccordian(this)">
    <span class="fa fa-plus"></span>
    English
  </div>
  <div class="accordian-body">
    English 101
  </div>
</div>

<div class="accordian-container collapsed">
  <div class="accordian-header" onclick="toggleAccordian(this)">
    <span class="fa fa-plus"></span>
    Math
  </div>
  <div class="accordian-body">
    Math 101
  </div>
</div>

<div class="accordian-container collapsed">
  <div class="accordian-header" onclick="toggleAccordian(this)">
    <span class="fa fa-plus"></span>
    Science
  </div>
  <div class="accordian-body">
    Science 101
  </div>
</div>
