This is the faculty page.
<?php

$serverName = ("sql.neit.edu");

//$db = new PDO("sqlsrv:server=$serverName; Database=SE414_GroupProject", "SE414_GroupProject", "1234567890");
$db = new PDO("sqlsrv:server=$serverName;Database=SE417_QW", "001356815", "001356815");
if ($db){
  echo "Connection Established.</br></br>";
} else {
  echo "Connection could not be established. </br>";
  die(print_r(sqlsrv_errors(), true));
}

$sql = 'SELECT * FROM Users';
foreach ($db -> query($sql) as $row){
  print $row['UserName'] . "\t";
    print $row['Pwd'] . "\t";
}

$serverName = ("sql.neit.edu");

$db = new PDO("sqlsrv:server=$serverName; Database=SE414_GroupProject", "SE414_GroupProject", "1234567890");
if ($db){
  echo "Connection Established.</br></br>";
} else {
  echo "Connection could not be established. </br>";
  die(print_r(sqlsrv_errors(), true));
}

$sql = 'SELECT * FROM Campus';
foreach ($db -> query($sql) as $row){
  print $row['campus_id'] . "\t";
    print $row['campus_name'] . "\t";
}

?>
