<h1>Add Curriculum</h1>

<form>
  <div class="form-row">
    <label>Curriculum Name:</label>
    <input type="text" />
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 1
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <button class="btn btn-default">Add</button>
        <button class="btn btn-default">Remove</button>
        <label class=""></label>
        <textarea class=""></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 2
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 3
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 4
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 5
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 6
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 7
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 8
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 9
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 10
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 11
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="accordian-container collapsed">
      <div class="accordian-header" onclick="toggleAccordian(this)">
        <span class="fa fa-plus"></span>
        Quarter 12
      </div>
      <div class="accordian-body">
        <label></label>
        <textarea></textarea>
        <label class="pull-right"></label>
        <textarea class="pull-right"></textarea>
      </div>
    </div>
  </div>

  <div class="form-row">
    <label></label>
    <button class="btn btn-default" onclick="loadPage('curriculum')">Cancel</button>
    <button class="btn btn-success" onclick="loadPage('curriculum')">Save</button>
  </div>
</form>
