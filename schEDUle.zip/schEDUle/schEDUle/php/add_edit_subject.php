<h1>Add/Edit Subject</h1>

<form>
  <div class="form-row">
    <label>Subject Name:</label>
    <input type="text" />
  </div>
  <div class="form-row">
    <label>Subject Code:</label>
    <input type="text" />
  </div>
  <div class="form-row">
    <label></label>
    <button class="btn btn-default" onclick="loadPage('course')">Cancel</button>
    <button class="btn btn-success" onclick="loadPage('course')">Save</button>
  </div>
</form>
