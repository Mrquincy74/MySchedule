<h1>Schedule Wizard</h1>

<form>
  <div class="form-row">
    <label>File:</label>
    <input type="text" />
  </div>
  <div class="form-row">
    <label></label>
    <button class="btn btn-default">Browse</button>
    <button class="btn btn-success" onclick="launchModal('.schedule-modal')">Upload</button>
  </div>
</form>
