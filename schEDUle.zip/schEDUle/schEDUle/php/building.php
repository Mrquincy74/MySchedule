<?php
  require_once '../php/autoload.php';
  $util = new Util();
  $dbc = new DB_Connect($util->getDBConfig());
  $connection = $dbc->getDBConnection();
  $campus_sql_result = odbc_exec($connection, "Select campus_id, campus_name, address_1 FROM [dbo].[Campus] order by campus_id");

  $campus_rows = array();
  $buidling_rows = array();

while($myRow = odbc_fetch_array( $campus_sql_result )){
    $campus_rows[] = $myRow;
}
odbc_close($connection);
/*
$building_sql_result = odbc_exec($connection, "Select campus_id, building_name FROM [dbo].[Building] WHERE 0=0");

while($myRow = odbc_fetch_array( $building_sql_result )){
    $building_rows[] = $myRow;
}

foreach($building_rows as $row) {
 foreach($row as $key => $value) {
     echo $key . ': '. $value;
 }
}
odbc_close($connection);*/
  ?>
<div class="header">
<h1>Current Campuses <span class="fa fa-plus-square pull-right" onclick="loadPage('add_edit_building')"> Add Building</span></h1>
</div>
<?php
$campus_id ="";

foreach($campus_rows as $row) {
  foreach($row as $key => $value) {
    if($key === "campus_id"){
      $campus_id = $value;
    }
    if($key === "address_1"){
      ?>
      <div class="accordian-container collapsed">
        <div class="accordian-header" onclick="toggleAccordian(this)">
          <span class="fa fa-plus"></span>
          <?php echo $value; ?>
        </div>
        <?php
        echo $campus_id;
        $building_sql_result = odbc_exec($connection, "Select building_name FROM [dbo].[Building] WHERE '$campus_id' = campus_id");

        while($myRow2 = odbc_fetch_array( $building_sql_result )){
            $building_rows[] = $myRow2;
        }

        odbc_close($connection);

        foreach($building_rows as $row2) {
          foreach($row2 as $building_key => $building_value) {
            if($building_key === "building_name"){
              ?>
                  <div class="accordian-body">
                  <?php echo $building_value; ?>
                  </div>
              <?php
            }
        ?>

  <?php
        }
    }
  ?>
     </div>
    <?php
    }
  }
}
?>
<!--<div class="accordian-container collapsed">
  <div class="accordian-header" onclick="toggleAccordian(this)">
    <span class="fa fa-plus"></span>
    Post Road Campus
  </div>
  <div class="accordian-body">
    This is the body.
  </div>
</div>-->
