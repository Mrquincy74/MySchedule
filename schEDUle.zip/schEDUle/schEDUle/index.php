<?php
  //phpinfo();
  require_once './php/autoload.php';
  $util = new Util();
  $dbc = new DB_Connect($util->getDBConfig());
  $login = new Login($dbc->getDBConnection());


// Find future way to determine where POST requests come from ie. Whether they are from the login form or from the
  if ( $util->isPostRequest() && $_SESSION['logged_in'] === "N") {
      $email = filter_input(INPUT_POST, 'login-email');
      $password = filter_input(INPUT_POST, 'login-password');
      $_SESSION['user_id'] = $login->getLogin($email, $password);
      echo $_SESSION['user_id'];
       $_SESSION['logged_in'] = "Y";
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <title>schEDUle</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link rel="stylesheet" href="dist/main.css" type="text/css" />
  </head>
     <!--<body onload="loadPage('login')">-->
   <?php if ($_SESSION['logged_in'] === "N") { ?>
     <body onload="loadPage('login')">
   <?php } else { ?>
     <body onload="loadPage('home')">
   <?php } ?>
    <div id="header">
      header stuff here
    </div>
    <div id="side-bar">
      <ul>
        <?php if ($_SESSION['user_id'] === "") { ?>
          <li onclick="loadPage('home')">Home</li>
          <li onclick="loadPage('login')">Log In</li>
        <?php } else { ?>
          <li onclick="loadPage('home')">Home</li>
          <li onclick="loadPage('building')">Building</li>
          <li onclick="loadPage('classroom')">Classroom</li>
          <li onclick="loadPage('course')">Course</li>
          <li onclick="loadPage('curriculum')">Curriculum</li>
          <li onclick="loadPage('faculty')">Faculty</li>
          <li onclick="loadPage('schedule-wizard')">Schedule Wizard</li>
          <!--<li onclick="loadPage('login')">Log In</li>-->
        <?php } ?>
      </ul>
    </div>

    <div id="container" class="content-container">

    </div>

    <div class="modal-bg">
    </div>

    <div class="modal-container demo-modal">
      <div class="modal-header">
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <button class="pull-right" onclick="closeModal('.demo-modal')">Close</button>
      </div>
    </div>

    <div class="modal-container schedule-modal">
      <div class="modal-header">
      </div>
      <div class="modal-body">
        <div class="alert-box info">
          <div class="alert-icon">
            <span class="fa fa-info-circle"></span>
          </div>
          <div class="alert-text">
            Schedule Uploaded Successfully
          </div>
        </div>

      </div>
      <div class="modal-footer">
        <button class="btn btn-success pull-right" onclick="closeModal('.schedule-modal')">Schedule</button>
        <button class="btn btn-default pull-right" onclick="closeModal('.schedule-modal')">Cancel</button>
      </div>
    </div>


<script src="dist/main.js" type="text/javascript"></script>

  </body>
</html>
